@extends('layouts.app')

@section('title', 'Control de Respaldos de Información - SGGDI')

@php
    $breadcrumbs = [
        [
            'name' => 'Inicio',
            'url' => route('welcome'),
            'icon' => 'fa-home'
        ],
        [
            'name' => 'Control de Respaldos de Información',
            'url' => null,
            'icon' => 'fa-floppy-disk'
        ]
    ];
@endphp

@push('styles')
<style>
    .module-section {
        background-color: #f8f9fa;
        border-radius: 15px;
        padding: 2rem;
        margin-bottom: 2rem;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    .form-row {
        background-color: white;
        padding: 1.5rem;
        border-radius: 10px;
        margin-bottom: 1rem;
    }
    .info-card {
        background-color: #e9ecef;
        padding: 1rem;
        border-radius: 10px;
        margin-bottom: 0.5rem;
    }
</style>
@endpush

@section('content')
<div class="container">
    <!-- Breadcrumb -->
    @include('partials.breadcrumb')
    
    <!-- Título del menú -->
    <div class="row mb-4">
        <div class="col-12">
            <h2 class="border-bottom pb-3">
                <i class="fas fa-floppy-disk me-2 text-secondary"></i>
                CONTROL DE RESPALDOS DE INFORMACIÓN
            </h2>
        </div>
    </div>

    <!-- CONFIGURACIÓN DE RESPALDO -->
    <div class="module-section">
        <h5 class="mb-4"><i class="fa-solid fa-gear"></i> CONFIGURACIÓN DEL RESPALDO</h5>
        
        <div class="form-row">
            <div class="row mb-3">
                <div class="col-md-6">
                    <label class="form-label">Destino de Descarga</label>
                    <input type="text" 
                           id="destino_automatico"
                           class="form-control"
                           placeholder="Seleccione el directorio..."
                           value="storage/backups">
                    <small class="text-muted">Directorio donde se guardarán los respaldos automáticos</small>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Seguridad</label>
                    <div class="form-check form-switch mt-2">
                        <input class="form-check-input" type="checkbox" id="cifrar_automatico">
                        <label class="form-check-label" for="cifrar_automatico">
                            <i class="fas fa-lock"></i> Cifrar script SQL
                        </label>
                    </div>
                </div>
            </div>    
            <div class="row mb-3">
                <div class="col-md-5 d-flex align-items-center gap-2">
                    <label class="form-label mb-0">Cada</label>
                    <select id="frecuencia_semanas" class="form-select w-auto">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                    </select>
                    <span>semana(s) y cada día</span>
                    <select id="frecuencia_dia_mes" class="form-select w-auto">
                        <option value="1">1</option>
                        @for($i=2; $i<=28; $i++)
                            <option value="{{ $i }}">{{ $i }}</option>
                        @endfor
                        <option value="30">30</option>
                        <option value="31">31</option>
                    </select>
                    <span>de cada mes</span>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Hora</label>
                    <input type="time" id="hora_automatico" class="form-control" value="15:00">
                </div>
            </div>

            <!-- Días de la semana -->
            <div class="row mb-3">
                <div class="col-md-8">
                    <label class="form-label d-block">Días de la semana para ejecutar el respaldo:</label>
                    <div class="d-flex flex-wrap gap-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="1" id="dia_lunes">
                            <label class="form-check-label" for="dia_lunes">Lunes</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="2" id="dia_martes">
                            <label class="form-check-label" for="dia_martes">Martes</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="3" id="dia_miercoles">
                            <label class="form-check-label" for="dia_miercoles">Miércoles</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="4" id="dia_jueves">
                            <label class="form-check-label" for="dia_jueves">Jueves</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="5" id="dia_viernes">
                            <label class="form-check-label" for="dia_viernes">Viernes</label>
                        </div>
                    </div>
                    <small class="text-muted">Seleccione los días en que se ejecutará el respaldo automático</small>
                </div>
            </div>
        </div>
    </div>

    <!-- NOVEDADES (HISTORIAL) -->
    <div class="module-section">
        <h5 class="mb-4"><i class="fa-solid fa-clock"></i> NOVEDADES</h5>
        
        <div class="row">
            <div class="col-md-12">
                <div class="info-card d-flex align-items-center gap-2 mb-2">
                    <label class="form-label fw-bold mb-0">Último backup automático:</label>
                    <span id="ultimo_backup_automatico" class="text-muted">—</span>
                </div>
                <div class="info-card d-flex align-items-center gap-2 ms-4">
                    <label class="form-label fw-bold mb-0">Usuario que estableció configuración actual:</label>
                    <span id="usuario_configuracion" class="text-muted">—</span>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="info-card d-flex align-items-center gap-2 mb-2">
                    <label class="form-label fw-bold mb-0">Último backup manual:</label>                    
                    <span id="ultimo_backup_manual" class="text-muted">—</span>
                </div>
                <div class="info-card d-flex align-items-center gap-2 ms-4">
                    <label class="form-label fw-bold mb-0">Usuario que realizó último backup manual:</label>
                    <span id="usuario_backup_manual" class="text-muted">—</span>
                </div>
            </div>
        </div>

    </div>

    <!-- CONTRASEÑA Y BOTONES -->
    <div class="row mt-4 pt-3 border-top">
        <div class="col-md-4">
            <label class="form-label">
                <i class="fas fa-lock me-2"></i>Contraseña de Administrador *
            </label>
            <input type="password" 
                   class="form-control" 
                   id="current_password" 
                   placeholder="Ingrese su contraseña para autorizar">
            <small class="text-muted">Requerida para confirmar cualquier operación</small>
        </div>
        <div class="col-md-8 d-flex align-items-end justify-content-end">
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-primary" id="btnDescargarManual">
                    <i class="fas fa-download me-2"></i>Descargar Respaldo
                </button>
                <button type="button" class="btn btn-success" id="btnGuardarConfiguracion">
                    <i class="fas fa-save me-2"></i>Guardar Configuración
                </button>                
                <button type="button" class="btn btn-outline-secondary" id="btnCancelarCambios">
                    <i class="fas fa-times me-2"></i>Cancelar Cambios
                </button>
            </div>
        </div>
    </div>

</div> 
@endsection

@push('scripts')
<script>
</script>
@endpush